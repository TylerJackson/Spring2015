﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
namespace Assign1CSharp
{
    class Hw2 : IHw2
    {
        public Tuple<int, int> SumEvenAndOdd(List<int> input)
        {
            var nums = from numb in input
                where numb%2 == 0
                select numb;
            int sumEven = input.Sum(num =>
            {
                if (num%2 == 0)
                {
                    return num;
                }
                return 0;
            });
            int sumOdd = input.Sum(num =>
            {
                if (num % 2 == 1)
                {
                    return num;
                }
                return 0;
            });
            return new Tuple<int, int>(sumEven,sumOdd);

        }

        public List<int> ListElementsDivisibleBy3(List<int> input)
        {
            var listOdds = input.Where(num => num%3 == 0).ToList();
            return listOdds;
            throw new NotImplementedException();
        }

        public List<int> ListElementsDivisibleBy3Recursive(List<int> input)
        {
            if (input.Count == 1)
            {
                if (input[0]%3 == 0)
                {
                    return input.GetRange(0,1);
                }
                else
                {
                    return new List<int>();
                }
            }
            else
            {
                if (input[0]%3 == 0)
                {
                    List<int> tempList = new List<int>(input[0]);
                    //tempList.AddRange(ListElementsDivisibleBy3Recursive(input.GetRange(1, input.Count - 1)));
                    return
                        tempList.Concat(ListElementsDivisibleBy3Recursive(input.GetRange(1, input.Count - 1))).ToList();
                }
                else
                {
                    return ListElementsDivisibleBy3Recursive(input.GetRange(1, input.Count - 1));
                }
            }

            throw new NotImplementedException();
        }

        public List<int> ListElementsDivisibleBy3Iterative(List<int> input)
        {
            var ans = new List<int>();
            foreach (var i in input)
            {
                if (i % 3 == 0) ans.Add(i);
            }
            return ans;
            throw new NotImplementedException();
        }

        public void LoadTest()
        {
            var testList1 = Enumerable.Range(1, 500000).ToList();
            var testList2 = Enumerable.Range(1, 500000).ToList();
            var testList3 = Enumerable.Range(1, 5000).ToList();
  
            var watch = new Stopwatch();
            watch.Start();
            this.ListElementsDivisibleBy3(testList1);
            watch.Stop();
            var timeLinq = watch.ElapsedMilliseconds;
            watch = Stopwatch.StartNew();
            this.ListElementsDivisibleBy3Iterative(testList2);
            watch.Stop();
            var timeIterative = watch.ElapsedMilliseconds;
            watch = Stopwatch.StartNew();
            this.ListElementsDivisibleBy3Recursive(testList3);
            watch.Stop();
            var timeRecursive = watch.ElapsedMilliseconds;

            var resultsList = new List<Tuple<String, long>>
                {
                    new Tuple<string, long>("ListElementsDivisibleBy3",timeLinq),
                    new Tuple<string, long>("ListElementsDivisibleBy3Iterative",timeIterative),
                    new Tuple<string, long>("ListElementsDivisibleBy3Recursive",timeRecursive)
                };
            resultsList = resultsList.OrderByDescending(x => x.Item2).ToList();
            Console.WriteLine("Number of elements for Iterative and Linq: {0} ", testList1.Count);
            Console.WriteLine("Number of elements for Recursive: {0} ", testList3.Count);
            foreach (var tuple in resultsList)
            {
                Console.WriteLine("{0}, with a time of {1}",tuple.Item1,tuple.Item2);
            }
        }
    }
}