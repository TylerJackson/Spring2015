﻿namespace MyListLib

type Hw2() = 
    interface IHw2 with
        member this.SumEvenAndOdd(temp) = 
            let mutable even = 0
            let mutable odd = 0
            for i in temp do
                if i%2 = 0 then
                    even<- even + i
                else
                    odd<- odd + i
            (even,odd)
        member this.ListElementsDivisibleBy3(temp) = 
            temp |> List.filter(fun x-> x%3 = 0)
        member this.ListElementsDivisibleBy3Iterative(temp) = 
            let lst = [ for i in 0..temp.Length-1 do if temp.[i]%3=0 then yield temp.[i]] 
            lst
        member this.ListElementsDivisibleBy3Recursive(temp1) = 
            let rec recur (temp:int list) =
                if temp.Length = 1 then 
                    if temp.[0]%3 = 0 then
                        [temp.[0]]
                    else
                        []
                else
                    let tempList = [for i in 1..temp.Length-1 -> temp.[i]]
                    if temp.[0]%3 = 0 then
                        [temp.[0]] @ recur(tempList)
                    else
                        recur(tempList)
            recur(temp1)
                    