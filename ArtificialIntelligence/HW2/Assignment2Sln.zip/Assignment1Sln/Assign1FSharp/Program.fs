﻿// Learn more about F# at http://fsharp.net
// See the 'F# Tutorial' project for more help.
open MyListLib
open System
open System.IO
open System.Diagnostics

[<EntryPoint>]
let main argv = 

    let hw2 = new Hw2()  
    let hw2Ready = hw2 :> IHw2

    let temp = hw2Ready.SumEvenAndOdd [1;2;3;4]

    let tempTest = [1..2000]

    let watch = new Stopwatch()
    watch.Start()
    let temp1 = hw2Ready.ListElementsDivisibleBy3 tempTest
    watch.Stop()
    let timeLinq = watch.ElapsedMilliseconds
    watch.Restart()
    let temp2 = hw2Ready.ListElementsDivisibleBy3Iterative tempTest
    watch.Stop()
    let timeIterative = watch.ElapsedMilliseconds
    watch.Restart()
    let temp3 = hw2Ready.ListElementsDivisibleBy3Recursive tempTest
    watch.Stop()
    let timeRecursive = watch.ElapsedMilliseconds    
   

    printfn "Number of Elements: %A" tempTest.Length
    printfn "Time for Elements Divisible By 3: %A" timeLinq
    printfn "Time for Elements Divisible By 3 Iterative: %A" timeIterative
    printfn "Time for Elements Divisible By 3 Recursive: %A" timeRecursive
    let a = Console.ReadKey()
    0 // return an integer exit code
