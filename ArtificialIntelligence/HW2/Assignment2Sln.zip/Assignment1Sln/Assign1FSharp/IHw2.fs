﻿namespace MyListLib

type IHw2 = 
    abstract member SumEvenAndOdd : int list -> int * int
    abstract member ListElementsDivisibleBy3 : int list -> int list
    abstract member ListElementsDivisibleBy3Iterative : int list -> int list
    abstract member ListElementsDivisibleBy3Recursive : int list -> int list

